# DMT_core
# Copyright (C) from 2022  SemiMod
# Copyright (C) until 2021  Markus Müller, Mario Krattenmacher and Pascal Kuthe
# <https://gitlab.com/dmt-development/dmt-core>
#
# This file is part of DMT_core.
#
# DMT_core is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# DMT_core is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>
import pkgutil
from pint import UnitRegistry
from pathlib import Path
from importlib.metadata import version
from packaging.version import Version as PyPIVersion

version_pkg = PyPIVersion(version("DMT-core"))
try:
    from semver.version import Version as VersionInfo
except ImportError:
    from semver import VersionInfo

version_pre = None
if version_pkg.pre:
    version_pre = ".".join(version_pkg.pre)

__version__ = VersionInfo(*version_pkg.release, prerelease=version_pre, build=version_pkg.dev)

# to get the next version:
# __version__.next_version(x) - with x = "major", "minor", "patch", "prerelease"
# or
# __version__.bump_x() - with x = "major", "minor", "patch", "prerelease"

name = "core"

from . import constants

# Helper
from .singleton import Singleton
from .hasher import create_md5_hash
from DMT.config import DATA_CONFIG

# one unit registry for all of DMT
unit_registry = UnitRegistry()
path_core = Path(__file__).resolve().parent
unit_registry.load_definitions(str(path_core / "dmt_units.txt"))

# helper for model equations and mcard memoization
from .utils import print_progress_bar
from .utils import enumerate_reversed

# naming conventions
from .naming import specifiers
from .naming import sub_specifiers
from .naming import specifiers_ss_para
from .naming import get_specifier_from_string
from .naming import get_nodes
from .naming import set_col_name
from .naming import SpecifierStr
from .naming import get_sub_specifiers
from .naming import natural_scales

# compact modelling stuff
from .mc_parameter import McParameter, McParameterCollection
from .va_file import VAFileMap
from .mcard import MCard
from .technology import Technology
from .circuit import Circuit, CircuitElement
from .mc_skywater import McSkywater

# plotting
from .plot import Plot
from .plot import save_or_show
from .plot import COMPARISON_3
from .plot_smith import SmithPlot
from .plot_2yaxis import Plot2YAxis

# Data management and processing
from .data_processor import is_iterable, flatten, strictly_increasing, DataProcessor

from .data_frame import DataFrame
from .sweep_def import (
    SweepDef,
    SweepDefConst,
    SweepDefLinear,
    SweepDefLog,
    SweepDefSync,
    SweepDefList,
)
from .sweep import Sweep, get_sweepdef
from .database_manager import DatabaseManager
from .data_reader import (
    read_data,
    save_elpa,
    read_ADS_bin,
    read_DEVICE_bin,
    read_elpa,
    read_mdm,
    read_hdf,
    read_feather,
)

# Simulation management
from .sim_con import SimCon

# DutView tree
from .dut_type import DutType, DutTypeFlag, DutTypeInt
from .dut_view import DutView
from .dut_lib import DutLib

from .dut_meas import DutMeas
from .dut_dummy import DutDummy

from .dut_circuit import DutCircuit

from .dut_tcad import DutTcad

_DEFAULT_DUT_VIEWS = [DutView, DutMeas, DutDummy, DutCircuit, DutTcad]
# docu
from .docu_dut_lib import DocuDutLib

# determine which modules are present
core_exists = True  # always, without DMT is not possible
try:
    pkgutil.find_loader("DMT.extraction")
    extraction_exists = True
except ImportError:
    extraction_exists = False
try:
    pkgutil.find_loader("DMT.hl2")
    bjt_exists = True
except ImportError:
    bjt_exists = False

print("-----------------------------------------------------------------------")
print("DMT Copyright (C) 2022 SemiMod")
print("This program comes with ABSOLUTELY NO WARRANTY.")
print("DMT.core is free software and licensed under GPLv3.")
if extraction_exists:
    print("DMT.extraction is free software and licensed under GPLv3.")
if bjt_exists:
    print("other DMT modules are free for non-commercial use, see LICENSE.md. ")
print("-----------------------------------------------------------------------")

Source:

ihttps://github.com/IHP-GmbH/IHP-Open-PDK/blob/main/ihp-sg13g2/libs.doc/meas/MOS/SG13_nmosXm1Y3/SG13_nmos~W05u0_L0u13_S542_1~dc_idvd_vbmin~300K.mdm

Supplied by IHP under  Apache-2.0 license. A copy of the license can be found in this folder.